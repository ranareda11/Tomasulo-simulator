class Load {
    constructor (
        timeRemaining,
        id,
        busy ,
        address,
        pos
      
    ){

    this.timeRemaining=timeRemaining,
    this.id=id,
    this.busy=busy,
   this.address=address
   this.pos=pos

    }

} 
module.exports= Load