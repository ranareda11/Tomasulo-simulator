class Store {
    constructor (
        timeRemaining,
        id,
        busy ,
        address,
        v,
        q,
        pos
     
        
    ){
    this.timeRemaining=timeRemaining,
    this.id=id,
    this.busy=busy,
   this.address=address,
   this.v=v,
   this.q=q,
   this.pos=pos

  
    }

} 
module.exports=Store