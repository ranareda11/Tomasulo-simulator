class Alu {
    constructor (
        timeRemaining,
        id,
        busy ,
        oper,
        vJ,
        vK,
        qJ,
        qK,
        pos,
      
    ){
    this.timeRemaining=timeRemaining,
    this.id=id,
    this.busy=busy,
    this.oper=oper,
    this.vJ=vJ,
    this.vK=vK,
    this.qJ=qJ,
    this.qK=qK
    this.pos=pos
   
    }

} 
module.exports= Alu